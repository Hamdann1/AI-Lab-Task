"""Lab 4: A* vs UCS audit, heuristic audit, and single-value overestimate experiment.
Usage: python lab4_astar_audit.py [graph.json]
Counting convention (used for BOTH A* and UCS): an expansion = a non-stale entry popped from the
priority queue and processed; the goal pop counts as an expansion (search stops on goal processing).
Stale pops (entry whose g is worse than best known g) are counted separately and are not expansions.
Priority = (f, h, insertion counter); UCS uses h=0 so priority = (g, counter).
"""
import heapq, json, sys, heapq as hq

def load(path):
    with open(path) as f: return json.load(f)

def build_adj(cfg):
    w = {}
    for u, v, c in cfg["edges"]:
        w[(u, v)] = c; w[(v, u)] = c
    return w

def search(cfg, h, label):
    w = build_adj(cfg); order = cfg["successor_order"]
    s, g_ = cfg["start"], cfg["goal"]
    counter = 0
    pq = [(h[s], h[s], counter, s, 0, (s,))]
    best = {s: 0}
    trace, expansions, stale_pops = [], 0, 0
    def snap():
        return [f"{n}(g={g},h={h[n]},f={g+h[n]})" for (f, hh, c, n, g, p) in sorted(pq)]
    while pq:
        f, hh, c, n, g, path = heapq.heappop(pq)
        if g > best.get(n, float("inf")):
            stale_pops += 1
            trace.append({"event": "stale-skip", "node": n, "g": g}); continue
        expansions += 1
        row = {"step": expansions, "selected": n, "g": g, "h": h[n], "f": g + h[n],
               "path": list(path), "remaining_frontier": snap(), "pushed": []}
        if n == g_:
            row["goal"] = True; trace.append(row)
            return dict(label=label, path=list(path), reported_cost=g, expansions=expansions,
                        stale_pops=stale_pops, left_in_queue=snap(), trace=trace)
        for m in order[n]:
            ng = g + w[(n, m)]
            if ng < best.get(m, float("inf")):
                best[m] = ng; counter += 1
                heapq.heappush(pq, (ng + h[m], h[m], counter, m, ng, path + (m,)))
                row["pushed"].append(f"{m}(g={g}+{w[(n,m)]}={ng},h={h[m]},f={ng+h[m]})")
        row["remaining_frontier_after_push"] = snap()
        trace.append(row)
    return dict(label=label, path=None, reported_cost=None, expansions=expansions,
                stale_pops=stale_pops, left_in_queue=[], trace=trace)

def independent_cost(cfg, path):
    # separate lookup straight from the raw edge list (does not reuse search internals)
    total, parts = 0, []
    for a, b in zip(path, path[1:]):
        c = next(c for u, v, c in cfg["edges"] if {u, v} == {a, b})
        parts.append(f"{a}-{b}={c}"); total += c
    return total, " + ".join(parts)

def dijkstra_true_h(cfg):
    """True remaining cost h*(n) to goal (graph is undirected, so run from goal)."""
    w = build_adj(cfg); dist = {cfg["goal"]: 0}; pq = [(0, cfg["goal"])]
    while pq:
        d, n = hq.heappop(pq)
        if d > dist[n]: continue
        for m in cfg["successor_order"][n]:
            if d + w[(n, m)] < dist.get(m, 1e9):
                dist[m] = d + w[(n, m)]; hq.heappush(pq, (dist[m], m))
    return dist

def audit(cfg, h):
    true_h = dijkstra_true_h(cfg); rows = []
    for n in cfg["successor_order"]:
        rows.append((n, h[n], true_h[n], "OK" if h[n] <= true_h[n] else "OVERESTIMATE"))
    cons = []
    for u, v, c in cfg["edges"]:
        for a, b in ((u, v), (v, u)):
            cons.append((a, b, c, h[a] - h[b], "OK" if h[a] <= c + h[b] else "VIOLATED"))
    return rows, cons

def fmt_run(r, cfg):
    cost, expr = independent_cost(cfg, r["path"])
    L = [f"=== {r['label']} ===", f"Path: {' -> '.join(r['path'])}",
         f"Reported cost: {r['reported_cost']}", f"Independent cost: {expr} = {cost}"
         f"  [{'MATCH' if cost == r['reported_cost'] else 'MISMATCH'}]",
         f"Expansions (goal counted): {r['expansions']}   Stale pops: {r['stale_pops']}   "
         f"Entries left in queue at stop: {len(r['left_in_queue'])} {r['left_in_queue']}", "Trace:"]
    for t in r["trace"]:
        if t.get("event"): L.append(f"  stale-skip {t['node']} g={t['g']}"); continue
        L.append(f"  #{t['step']} select {t['selected']} g={t['g']} h={t['h']} f={t['f']} path={'-'.join(t['path'])}")
        L.append(f"      frontier after pop: {t['remaining_frontier']}")
        if t.get("goal"): L.append("      GOAL processed -> stop")
        else: L.append(f"      pushed: {t['pushed'] or 'none'}")
    return "\n".join(L), cost

def main():
    cfg = load(sys.argv[1] if len(sys.argv) > 1 else "graph.json")
    h0 = dict(cfg["h"]); zero = {n: 0 for n in h0}
    runs = {"astar": search(cfg, h0, "A* (supplied heuristic)"),
            "ucs": search(cfg, zero, "UCS (zero heuristic control)")}
    h_c = dict(h0); h_c["C"] = 10
    runs["astar_hC10"] = search(cfg, h_c, "A* with h(C)=10 (overestimate)")
    h_d = dict(h0); h_d["D"] = 10
    runs["astar_hD10"] = search(cfg, h_d, "A* with h(D)=10 (overestimate off the optimal path)")
    out = []
    rows, cons = audit(cfg, h0)
    out.append("=== HEURISTIC AUDIT (original h) ===\nnode h h* status")
    out += [f"  {n}  h={a}  h*={b}  {s}" for n, a, b, s in rows]
    out.append("consistency h(a) <= c(a,b) + h(b):")
    out += [f"  {a}->{b} c={c} h(a)-h(b)={d} {s}" for a, b, c, d, s in cons]
    rowsC, _ = audit(cfg, h_c)
    out.append("\n=== AUDIT with h(C)=10 ===")
    out += [f"  {n}  h={a}  h*={b}  {s}" for n, a, b, s in rowsC if s != "OK" or n == "C"]
    summary = []
    for k, r in runs.items():
        txt, cost = fmt_run(r, cfg); out.append("\n" + txt)
        summary.append((r["label"], "-".join(r["path"]), cost, r["expansions"], r["stale_pops"]))
    opt = independent_cost(cfg, runs["ucs"]["path"])[0]
    out.append("\n=== SUMMARY ===\nrun | path | independent cost | expansions | stale pops | optimal?")
    for lab, p, c, e, sp in summary:
        out.append(f"{lab} | {p} | {c} | {e} | {sp} | {'yes' if c == opt else 'NO (optimal=%d)' % opt}")
    text = "\n".join(out); print(text)
    open("outputs/run_output.txt", "w").write(text + "\n")
    json.dump({k: {**v, "independent_cost": independent_cost(cfg, v["path"])[0]} for k, v in runs.items()},
              open("outputs/results.json", "w"), indent=1)

if __name__ == "__main__":
    main()
