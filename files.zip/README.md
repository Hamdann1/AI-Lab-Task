# Lab 4 – A* vs UCS audit

Files
- `lab4_astar_audit.py` – A*, UCS (zero-heuristic control), heuristic audit, overestimate experiments
- `graph.json` – graph, successor order, heuristic, tie-break rule (**ASSUMED data, see note**)
- `outputs/run_output.txt`, `outputs/results.json` – captured output of the run below
- `Lab4_Report.docx` – report

Setup / run (Python 3.8+, standard library only)
```
cd lab4
python lab4_astar_audit.py            # uses graph.json
python lab4_astar_audit.py other.json # any graph in the same format
```

**Note:** the handout's campus graph and heuristic were not available when this was written, so `graph.json`
holds a clearly stated assumed graph that satisfies the lab's structure (start S, goal G, node C, h(C)=10 experiment).
To use the official data, replace `graph.json` (same keys) and rerun; the report numbers must then be regenerated.

Counting convention (A* and UCS): expansion = non-stale pop processed; goal pop counts; stale pops reported separately.
Tie-break: lowest f, then lowest h, then FIFO insertion order.

References: Russell & Norvig, *Artificial Intelligence: A Modern Approach*; Hart, Nilsson & Raphael (1968) A* paper;
Python `heapq` documentation. No third-party code used.
