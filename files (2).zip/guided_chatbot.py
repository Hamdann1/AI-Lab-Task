"""FAQ chatbot, TF-IDF backend. (Reconstruction of the guided file: build_bot(), reply(engine, text).)
Behaviour: exact normalized match -> answer + source; similar question -> 'Possible matches' and a request
for confirmation (never asserted as the answer); otherwise 'No matching FAQ'. Run: python guided_chatbot.py"""
import json, re
from sklearn.feature_extraction.text import TfidfVectorizer

SUGGEST_MIN = 0.25   # my choice; checked on the small FAQ set below, not a universal cutoff

def norm(t): return re.sub(r"[^\w\s]", "", t.lower()).strip()

def build_bot(path="faq.json"):
    faqs = json.load(open(path, encoding="utf-8"))
    vec = TfidfVectorizer(stop_words="english"); M = vec.fit_transform([f["q"] for f in faqs])
    return dict(faqs=faqs, vec=vec, M=M)

def candidates(engine, text):
    s = (engine["vec"].transform([text]) @ engine["M"].T).toarray()[0]
    return [(i, s[i]) for i in s.argsort()[::-1][:3] if s[i] >= SUGGEST_MIN]

def reply(engine, text):
    if not text.strip(): return "Please enter a question."
    for f in engine["faqs"]:
        if norm(f["q"]) == norm(text): return f"{f['a']}  [source: {f['source']}]"
    top = candidates(engine, text)
    if not top: return "No matching FAQ found. Please rephrase or contact a human."
    lines = [f"  {n}. {engine['faqs'][i]['q']} (score {sc:.2f}, source: {engine['faqs'][i]['source']})"
             for n, (i, sc) in enumerate(top, 1)]
    return "Possible matches (not confirmed):\n" + "\n".join(lines) + "\nIs one of these what you meant? Reply with its number to see the answer."

if __name__ == "__main__":
    e = build_bot(); print("FAQ bot. Type exit to stop.")
    while True:
        try: q = input("Question: ")
        except (EOFError, KeyboardInterrupt): break
        if q.strip().lower() == "exit": break
        r = reply(e, q); print(r)
        if r.startswith("Possible"):
            top = candidates(e, q); c = input("Number (Enter if none): ")
            if c.isdigit() and 1 <= int(c) <= len(top):
                f = e["faqs"][top[int(c) - 1][0]]; print(f"{f['a']}  [source: {f['source']}]")
            else: print("No answer selected.")
