# Lab 6 – Tokenization, chunking, retrieval and document chatbot

## Setup
```
python -m venv .venv && source .venv/bin/activate      # do not commit .venv
pip install -r requirements.txt                          # sentence-transformers downloads all-MiniLM-L6-v2 on first run
python create_dataset.py                                 # creates corpus.json, queries.json, rule_exception.json (use --force to overwrite)
```
## Run
- Task 1: `python task1_tokens.py`; `python task1_chatbot_check.py`; `python guided_chatbot.py`
- Task 2: `python task2_chunks.py`; `python task2_semantic_check.py`
- Task 3: `python task3_retrieval.py` (writes retrieval_log.csv, results.json, selected_config.json); `python document_chatbot.py`

## Status of results (honest)
Produced here: everything with TF-IDF. **Not run** (no network / sentence-transformers in my environment): the
embedding configurations, model-tokenizer comparison, model token-length audit and model-load timing. Those code paths
exist and print "NOT RUN" when unavailable; run them on your machine and regenerate retrieval_log.csv/results.json
before submitting. The instructor-supplied guided files (guided_embeddings.py, guided_suggestions.py, five scenario
scripts) were not available to me; `guided_chatbot.py` and `lab6_search.py` are my reconstructions of the described interface.

## Provenance
Chunking core and evaluation structure adapted from the lab-manual reference solution; corpus, queries, FAQ entries,
trimming, statistics, calibration and chatbot additions are my own. Model: sentence-transformers/all-MiniLM-L6-v2
(Hugging Face model card). No credentials, caches or virtual environments are included.
