"""Task 3: evaluate word windows (0/10) and sentence packing with TF-IDF and sentence embeddings.
Structure follows the manual's reference; additions (graceful skip, token audit fallback, threshold
calibration, failure listing, JSON summary) are mine. Run: python task3_retrieval.py"""
import csv, json, time
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from task2_chunks import make_chunks

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

def ranks(scores_row, chunks, q):
    top = np.argsort(-scores_row, kind="stable")[:3]
    return [r for r, i in enumerate(top, 1) if chunks[i]["doc"] == q["doc"] and q["evidence"] in chunks[i]["text"]]

def evaluate(scores, chunks, items):
    hits, rr = [], []
    for row, q in zip(scores, items):
        if q["doc"] is None: continue
        good = ranks(row, chunks, q); hits.append(bool(good)); rr.append(1 / good[0] if good else 0)
    return (float(np.mean(hits)), float(np.mean(rr))) if hits else (None, None)

def calibrate(scores, items):
    """Rejection threshold from DEV only: midpoint between best dev-unanswerable top-1 and worst dev-answerable top-1."""
    top1 = scores.max(axis=1)
    ans = [top1[i] for i, q in enumerate(items) if q["split"] == "dev" and q["doc"]]
    una = [top1[i] for i, q in enumerate(items) if q["split"] == "dev" and q["doc"] is None]
    if not ans or not una or max(una) >= min(ans): return None, (min(ans), max(una)) if ans and una else None
    return float((max(una) + min(ans)) / 2), (min(ans), max(una))

def main():
    docs = json.load(open("corpus.json", encoding="utf-8")); items = json.load(open("queries.json", encoding="utf-8"))
    for q in items:
        assert q["split"] in {"dev", "test"}
        if q["doc"]: assert q["evidence"] in docs[q["doc"]]
    qtexts = [q["query"] for q in items]
    model, load_s = None, None
    try:
        from sentence_transformers import SentenceTransformer
        t = time.perf_counter(); model = SentenceTransformer(MODEL_NAME, device="cpu"); load_s = time.perf_counter() - t
        print(f"Model load seconds (separate from encoding): {load_s:.2f}")
    except Exception as e:
        print("EMBEDDINGS NOT RUN:", type(e).__name__, "-", e, "\n(TF-IDF alone does not satisfy the semantic-embedding requirement.)")
    logs, summary, failures = [], [], []
    for strategy in ["0", "10", "sentence"]:
        chunks = make_chunks(docs, strategy); texts = [c["text"] for c in chunks]
        if model:
            L = [len(model.tokenizer(t, truncation=False)["input_ids"]) for t in texts + qtexts]
            print(f"[{strategy}] model token lengths: max={max(L)} mean={np.mean(L):.1f} limit={model.max_seq_length}")
            if max(L) > model.max_seq_length: raise ValueError("Model limit exceeded; rechunk or shorten query")
        else: print(f"[{strategy}] model token audit NOT RUN (no tokenizer available)")
        for method in ["tfidf", "embedding"]:
            if method == "embedding" and model is None:
                summary.append(dict(strategy=strategy, method=method, status="NOT RUN", chunks=len(chunks))); continue
            t = time.perf_counter()
            if method == "tfidf":
                v = TfidfVectorizer(); C = v.fit_transform(texts); Q = v.transform(qtexts)
            else:
                C = model.encode(texts, normalize_embeddings=True); Q = model.encode(qtexts, normalize_embeddings=True)
            enc = time.perf_counter() - t; t = time.perf_counter()
            scores = (Q @ C.T).toarray() if method == "tfidf" else Q @ C.T
            srch = time.perf_counter() - t
            thr, edges = calibrate(scores, items)
            rec = dict(strategy=strategy, method=method, status="ok", chunks=len(chunks), encode_s=enc, search_s=srch, threshold=thr, calib_edges=edges)
            for split in ["dev", "test"]:
                idx = [i for i, q in enumerate(items) if q["split"] == split]
                h, m = evaluate(scores[idx], chunks, [items[i] for i in idx]); rec[f"{split}_hit3"] = h; rec[f"{split}_mrr3"] = m
            if thr is not None:  # apply the dev-calibrated threshold to the untouched test split
                te = [(scores[i].max() >= thr, items[i]["doc"] is not None) for i, q in enumerate(items) if q["split"] == "test"]
                rec["test_unanswerable_rejected"] = sum(1 for acc, a in te if not a and not acc)
                rec["test_answerable_rejected"] = sum(1 for acc, a in te if a and not acc)
            summary.append(rec)
            for row, q in zip(scores, items):
                top = np.argsort(-row, kind="stable")[:3]
                for rank, i in enumerate(top, 1):
                    c = chunks[i]
                    logs.append(dict(strategy=strategy, method=method, query=q["query"], split=q["split"], answerable=q["doc"] is not None,
                                     rank=rank, score=float(row[i]), chunk_id=c["id"], doc=c["doc"], start=c["start"], end=c["end"],
                                     evidence_in_chunk=bool(q["doc"] and c["doc"] == q["doc"] and q["evidence"] in c["text"]), text=c["text"]))
                if q["doc"]:
                    g = ranks(row, chunks, q)
                    if not g or g[0] != 1:
                        failures.append(dict(strategy=strategy, method=method, split=q["split"], query=q["query"],
                                             first_good_rank=g[0] if g else None, top1=chunks[top[0]]["id"], top1_score=float(row[top[0]]),
                                             top1_text=chunks[top[0]]["text"][:140]))
    for r in summary: print(r)
    with open("retrieval_log.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(logs[0])); w.writeheader(); w.writerows(logs)
    # strategy choice on DEV only (per method that ran); held-out TEST numbers are only reported, never used to choose
    ok = [r for r in summary if r["status"] == "ok"]
    best = max(ok, key=lambda r: (r["dev_mrr3"], r["dev_hit3"], -r["chunks"]))
    print("\nSELECTED on dev (MRR@3, then Hit@3, then fewer chunks):", best["strategy"], best["method"],
          "| dev", best["dev_hit3"], best["dev_mrr3"], "| held-out test", best["test_hit3"], best["test_mrr3"])
    json.dump(dict(model_load_s=load_s, summary=summary, failures=failures, selected=dict(strategy=best["strategy"], backend=best["method"], threshold=best["threshold"])),
              open("results.json", "w"), indent=1, default=str)
    json.dump(dict(strategy=best["strategy"], backend=best["method"], threshold=best["threshold"]), open("selected_config.json", "w"))
    print(f"\n{len(failures)} failures (answerable query where the evidence chunk is not rank 1):")
    for f_ in failures[:12]: print(" ", f_["strategy"], f_["method"], f_["split"], repr(f_["query"]), "first_good_rank", f_["first_good_rank"], "top1", f_["top1"], round(f_["top1_score"], 3))

if __name__ == "__main__":
    main()
