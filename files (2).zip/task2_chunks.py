"""Task 2: word windows (overlap 0/10) and sentence-aware packing, with source offsets and IDs.
Core functions adapted from the lab-manual reference solution (instructor reference); the trimming of
chunk offsets, statistics and tests are my own additions. Run: python task2_chunks.py"""
import json, re

def word_spans(text):
    return [(m.start(), m.end()) for m in re.finditer(r"\S+", text)]

def windows(text, size=40, overlap=10, offset=0):
    if size <= 0 or not 0 <= overlap < size:
        raise ValueError("Require size > 0 and 0 <= overlap < size")
    spans = word_spans(text); result = []
    for i in range(0, len(spans), size - overlap):
        j = min(i + size, len(spans))
        result.append((offset + spans[i][0], offset + spans[j - 1][1]))
        if j == len(spans): break
    return result

def sentence_chunks(text, size=40):
    if size <= 0: raise ValueError("size must be positive")
    # Teaching splitter: punctuation followed by whitespace (fails on abbreviations such as "Dr. Khan").
    cuts = [0] + [m.end() for m in re.finditer(r"[.!?]\s+", text)] + [len(text)]
    out, pending, count = [], None, 0
    for a, b in zip(cuts, cuts[1:]):
        n = len(text[a:b].split())
        if not n: continue
        if n > size:
            if pending is not None: out.append(pending)
            out.extend(windows(text[a:b], size, 0, a)); pending, count = None, 0
        elif pending is not None and count + n <= size:
            pending, count = (pending[0], b), count + n
        else:
            if pending is not None: out.append(pending)
            pending, count = (a, b), n
    if pending is not None: out.append(pending)
    return out

def _trim(text, a, b):
    seg = text[a:b]; return a + (len(seg) - len(seg.lstrip())), b - (len(seg) - len(seg.rstrip()))

def make_chunks(docs, strategy):
    result = []
    for doc_id, text in docs.items():
        spans = sentence_chunks(text) if strategy == "sentence" else windows(text, 40, int(strategy))
        for i, (a, b) in enumerate(spans):
            a, b = _trim(text, a, b)
            result.append(dict(id=f"{doc_id}:{i}", doc=doc_id, start=a, end=b, text=text[a:b]))
    return result

def stats(docs, chunks):
    sizes = [len(c["text"].split()) for c in chunks]
    orig = sum(len(t.split()) for t in docs.values())
    return dict(chunks=len(chunks), min=min(sizes), max=max(sizes), mean=round(sum(sizes) / len(sizes), 1),
                emitted_words=sum(sizes), original_words=orig, duplicated_words=sum(sizes) - orig)

def survival(chunks, pairs):
    """rule/exception labelled substrings: how many docs keep BOTH in a single chunk?"""
    kept, rows = 0, []
    for doc, (rule, exc) in pairs.items():
        ok = any(c["doc"] == doc and rule in c["text"] and exc in c["text"] for c in chunks)
        kept += ok; rows.append((doc, ok))
    return kept, rows

if __name__ == "__main__":
    # --- boundary tests ---
    assert windows("") == [] and sentence_chunks("") == []
    assert windows("short text") == [(0, 10)]
    for bad in [(2, 2), (2, -1), (0, 0)]:
        try: windows("a b", *bad)
        except ValueError: pass
        else: raise AssertionError("invalid parameters accepted: %s" % (bad,))
    long = " ".join(["word"] * 95) + "."
    assert all(len(long[a:b].split()) <= 40 for a, b in sentence_chunks(long)) and len(sentence_chunks(long)) == 3
    short_doc = {"s": "Reset your password. Keep recovery codes private."}
    assert len(make_chunks(short_doc, "sentence")) == 1 and len(make_chunks(short_doc, "0")) == 1
    print("boundary tests passed: empty, short doc, invalid overlap, 95-word sentence -> 3 fallback windows")

    docs = json.load(open("corpus.json", encoding="utf-8")); pairs = json.load(open("rule_exception.json"))
    for strat in ["0", "10", "sentence"]:
        ch = make_chunks(docs, strat)
        assert all(c["text"] == docs[c["doc"]][c["start"]:c["end"]] and c["text"] for c in ch)
        kept, rows = survival(ch, pairs)
        print(f"\nstrategy={strat}: {stats(docs, ch)}")
        print(f"  rule+exception in one chunk: {kept}/{len(pairs)}  ->", dict(rows))
    # abbreviation failure demo
    d = docs["assignment"]; i = d.index("Dr."); print("\nSplitter failure demo (abbreviation):")
    for c in make_chunks({"assignment": d}, "sentence"):
        if c["start"] <= i < c["end"] or abs(c["start"] - (i + 4)) < 3:
            print(" ", c["id"], repr(c["text"][:60]), "...")
    print("  cuts after 'Dr. ' -> 'Khan's section ...' starts mid-sentence:",
          any(c["text"].startswith("Khan") for c in make_chunks({"assignment": d}, "sentence")))
