"""Retriever with TF-IDF or sentence-embedding backend. (Reconstruction: the supplied lab6_search.py was not
available to me; interface follows the manual: Retriever(records, backend).search(query, k) -> [(record, score)].)"""
import numpy as np

EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

class Retriever:
    def __init__(self, records, backend="tfidf"):
        self.records, self.backend = records, backend
        texts = [r["text"] for r in records]
        if backend == "tfidf":
            from sklearn.feature_extraction.text import TfidfVectorizer
            self.vec = TfidfVectorizer(); self.C = self.vec.fit_transform(texts)
        elif backend == "embedding":
            from sentence_transformers import SentenceTransformer  # ImportError if not installed
            self.model = SentenceTransformer(EMBED_MODEL, device="cpu")
            self.C = self.model.encode(texts, normalize_embeddings=True)
        else:
            raise ValueError("backend must be 'tfidf' or 'embedding'")

    def scores(self, query):
        if self.backend == "tfidf": return (self.vec.transform([query]) @ self.C.T).toarray()[0]
        return self.model.encode([query], normalize_embeddings=True)[0] @ self.C.T

    def search(self, query, k=3):
        if not query.strip(): return []
        s = self.scores(query); top = np.argsort(-s, kind="stable")[:k]
        if self.backend == "tfidf": top = [i for i in top if s[i] > 0]   # zero overlap = no candidate
        return [(self.records[i], float(s[i])) for i in top]

def show_hits(hits):
    if not hits: print("  (no hits)")
    for r, s in hits: print(f"  {r['id']} score={s:.3f} chars {r['start']}-{r['end']}: {r['text'][:90]}...")
