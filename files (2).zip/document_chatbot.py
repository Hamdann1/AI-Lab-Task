"""Interactive evidence assistant using the configuration selected by task3_retrieval.py (selected_config.json).
Candidates are shown with IDs, scores and offsets; the passage is displayed only after the user confirms one.
Run: python document_chatbot.py   (needs corpus.json; run task3_retrieval.py first)"""
import json
from task2_chunks import make_chunks
from lab6_search import Retriever

if __name__ == "__main__":
    docs = json.load(open("corpus.json", encoding="utf-8"))
    cfg = json.load(open("selected_config.json")) if __import__("os").path.exists("selected_config.json") else dict(strategy="sentence", backend="tfidf", threshold=None)
    try: engine = Retriever(make_chunks(docs, cfg["strategy"]), cfg["backend"])
    except ImportError:
        print("Embedding backend unavailable; falling back to TF-IDF."); engine = Retriever(make_chunks(docs, cfg["strategy"]), "tfidf")
    print(f"Evidence assistant (strategy={cfg['strategy']}, backend={engine.backend}). Type exit to stop.")
    while True:
        try: query = input("Question: ")
        except (EOFError, KeyboardInterrupt): break
        if query.strip().lower() == "exit": break
        if not query.strip(): print("Please enter a question."); continue
        hits = engine.search(query)
        if not hits: print("No candidate evidence; rephrase or contact a human."); continue
        thr = cfg.get("threshold")
        if thr is not None and hits[0][1] < thr: print("Warning: top score is below the dev-calibrated threshold; this may be unsupported.")
        print("Candidate evidence; relevance must be checked:")
        for n, (r, s) in enumerate(hits, 1): print(n, r["id"], f"{s:.3f}", "characters", r["start"], r["end"])
        chosen = input("Choose 1-3 to inspect; Enter if none apply: ")
        if not chosen.isdigit() or not 1 <= int(chosen) <= len(hits):
            print("No answer selected. Rephrase or contact a human."); continue
        r, s = hits[int(chosen) - 1]
        print("Retrieved passage:", r["text"]); print("Source:", r["doc"], "characters", r["start"], r["end"])
        print("(Unverified candidate: check it against the source document before relying on it.)")
