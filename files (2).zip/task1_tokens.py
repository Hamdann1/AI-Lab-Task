"""Task 1: whitespace vs Unicode word-like regex tokens; optional model subword tokenizer.
The regex r"\\b\\w+\\b" is a teaching tool, NOT a complete multilingual tokenizer."""
import re
samples = ["AI, search!", "I can't log in.", "help@example.com", "CS4944", "",
           "یہ ایک مثال ہے", "Version 2.1 costs $4.50"]
for text in samples:
    ws = text.split()
    words = re.findall(r"\b\w+\b", text, flags=re.UNICODE)
    print(repr(text)); print("  whitespace:", ws, len(ws)); print("  word-like :", words, len(words))
assert re.findall(r"\b\w+\b", "") == [] and "".split() == []
assert len("I can't log in.".split()) == 4 and len(re.findall(r"\b\w+\b", "I can't log in.")) == 5

# Optional model tokenizer (first use downloads the model; needs network + sentence-transformers)
try:
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2", device="cpu")
    for text in samples[:2]:
        print("model subwords:", repr(text), model.tokenizer.tokenize(text))
except Exception as e:
    print("MODEL TOKENIZER NOT RUN:", type(e).__name__, "-", e)
