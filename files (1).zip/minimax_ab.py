"""Minimax vs alpha-beta with leaf-evaluation counters, ordering experiments.
Tree = nested lists; an int is a leaf. Root is MAX. Run: python minimax_ab.py
ASSUMED tree (handout tree not available): the classic 2-ply example
   MAX -> B[3,12,8], C[2,4,6], D[14,5,2]   (value 3).  Replace TREE to use the supplied tree.
"""
import itertools, random

TREE = [[3, 12, 8], [2, 4, 6], [14, 5, 2]]

class Counter:
    def __init__(self): self.leaves = 0

def minimax(node, is_max, c, trace=None, depth=0):
    if isinstance(node, int):
        c.leaves += 1
        if trace is not None: trace.append(f"{'  '*depth}leaf {node}")
        return node
    vals = []
    for ch in node:
        vals.append(minimax(ch, not is_max, c, trace, depth + 1))
    v = max(vals) if is_max else min(vals)
    if trace is not None: trace.append(f"{'  '*depth}{'MAX' if is_max else 'MIN'} -> {v}  (children {vals})")
    return v

def alphabeta(node, is_max, alpha, beta, c, trace=None, depth=0):
    if isinstance(node, int):
        c.leaves += 1
        if trace is not None: trace.append(f"{'  '*depth}leaf {node}")
        return node
    v = float("-inf") if is_max else float("inf")
    for i, ch in enumerate(node):
        r = alphabeta(ch, not is_max, alpha, beta, c, trace, depth + 1)
        if is_max: v = max(v, r); alpha = max(alpha, v)
        else:      v = min(v, r); beta = min(beta, v)
        if alpha >= beta:
            if trace is not None and i < len(node) - 1:
                trace.append(f"{'  '*depth}PRUNE after child {i+1}: alpha={alpha} >= beta={beta}, skip {len(node)-i-1} sibling(s)")
            break
    if trace is not None: trace.append(f"{'  '*depth}{'MAX' if is_max else 'MIN'} -> {v}  (alpha={alpha}, beta={beta})")
    return v

def run(tree, label, show=False):
    c1, c2 = Counter(), Counter(); t1, t2 = ([] if show else None), ([] if show else None)
    v1 = minimax(tree, True, c1, t1); v2 = alphabeta(tree, True, float("-inf"), float("inf"), c2, t2)
    assert v1 == v2, "VALUE MISMATCH"
    if show:
        print(f"--- Minimax trace ({label}) ---"); print("\n".join(t1))
        print(f"--- Alpha-beta trace ({label}) ---"); print("\n".join(t2))
    print(f"{label}: value={v1} minimax_leaves={c1.leaves} alphabeta_leaves={c2.leaves} pruned={c1.leaves-c2.leaves}")
    return v1, c1.leaves, c2.leaves

def count_leaves(n): return 1 if isinstance(n, int) else sum(count_leaves(x) for x in n)

if __name__ == "__main__":
    print("== Task 1/2: supplied (assumed) tree, original order ==")
    run(TREE, "original order", show=True)

    print("\n== Task 3: reorder branches (value must stay the same) ==")
    named = {
        "original B,C,D; leaves as given": TREE,
        "reverse root order D,C,B": [TREE[2], TREE[1], TREE[0]],
        "best-first inside each MIN (ascending leaves)": [sorted(b) for b in TREE],
        "ascending leaves + MIN nodes sorted by value, best first": [sorted(b) for b in sorted(TREE, key=min, reverse=True)],
        "worst-first inside each MIN (descending leaves)": [sorted(b, reverse=True) for b in TREE],
        "descending leaves + weakest MIN node first": [sorted(b, reverse=True) for b in sorted(TREE, key=min)],
    }
    for k, t in named.items(): run(t, k)

    print("\n== Exhaustive: all 6 root orders x 6^3 leaf orders = 1296 orderings ==")
    res = []
    for root_perm in itertools.permutations(range(3)):
        for lp in itertools.product(*[list(itertools.permutations(TREE[i])) for i in root_perm]):
            t = [list(x) for x in lp]; c = Counter()
            v = alphabeta(t, True, float("-inf"), float("inf"), c); res.append((c.leaves, v, t))
    leaves = [r[0] for r in res]
    print("distinct root values:", sorted({r[1] for r in res}))
    print("alpha-beta leaves: min", min(leaves), " max", max(leaves), " mean %.2f" % (sum(leaves)/len(leaves)))
    from collections import Counter as C2
    print("distribution:", dict(sorted(C2(leaves).items())))
    print("a best-case ordering:", min(res, key=lambda r: r[0])[2])
    print("a worst-case ordering:", max(res, key=lambda r: r[0])[2])

    print("\n== Edge cases ==")
    run([[5, 5, 5], [5, 5, 5]], "all-equal leaves (ties)")
    run([[1], [2]], "branching factor 1")
    run([[9, 1], [8, 2], [7, 3]], "descending MAX candidates")

    print("\n== Random validation: 2000 random trees (depth 3 or 4, branching 2-4) ==")
    random.seed(0)
    def rnd(d, b):
        return random.randint(-20, 20) if d == 0 else [rnd(d - 1, random.randint(2, b)) for _ in range(random.randint(2, b))]
    bad = worse = tot_m = tot_a = 0
    for _ in range(2000):
        t = rnd(random.choice([3, 4]), 4); c1, c2 = Counter(), Counter()
        v1 = minimax(t, True, c1); v2 = alphabeta(t, True, float("-inf"), float("inf"), c2)
        bad += v1 != v2; worse += c2.leaves > c1.leaves; tot_m += c1.leaves; tot_a += c2.leaves
    print(f"value mismatches: {bad}   trees where alpha-beta used MORE leaves: {worse}")
    print(f"total leaves minimax={tot_m} alpha-beta={tot_a} ({100*(1-tot_a/tot_m):.1f}% fewer)")
