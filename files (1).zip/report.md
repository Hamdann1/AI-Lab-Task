# Lab: Minimax vs Alpha-Beta (leaf counters and move ordering)

**Assumption:** the handout's supplied tree was not available, so the classic 2-ply tree was used:
root MAX with MIN children B[3,12,8], C[2,4,6], D[14,5,2]. Replace `TREE` in `minimax_ab.py` with the supplied tree
and rerun (`python minimax_ab.py`); the numbers below must then be regenerated.

## 1. Hand trace (Minimax)
B = min(3,12,8) = 3; C = min(2,4,6) = 2; D = min(14,5,2) = 2; root = max(3,2,2) = **3**. All 9 leaves are evaluated.

Alpha-beta by hand: B: leaf 3 gives beta=3, leaves 12 and 8 do not lower it, B=3, root alpha=3.
C: alpha=3, leaf 2 gives beta=2 <= alpha, so leaves 4 and 6 are pruned, C=2.
D: leaf 14, then 5, then 2 (beta=2 <= alpha, but it was the last leaf, nothing left to prune), D=2. Root = 3 with **7 leaves**.

## 2. Leaf counters (output.txt)
| Ordering | Value | Minimax leaves | Alpha-beta leaves |
|---|---|---|---|
| original | 3 | 9 | 7 |
| reverse root order | 3 | 9 | 7 |
| ascending leaves (best-first for MIN) | 3 | 9 | 5 |
| descending leaves (worst-first) | 3 | 9 | 9 |

## 3. Reordering
Over all 1296 orderings (6 root orders x 6^3 leaf orders) the root value is always 3 while alpha-beta evaluates
5 to 9 leaves (mean 7.67; distribution 5:48, 6:96, 7:432, 8:384, 9:336). Ordering changes work, never the value.
Pruning in a MIN node needs a small value early; ordering the strongest refutation first prunes the most, and the worst
ordering prunes nothing so alpha-beta matches Minimax (never more leaves).

## 4. Edge cases and limitations
- All-equal leaves: value 5, 4 leaves instead of 6 because `alpha >= beta` also prunes ties. The value is correct, but this
  kind of pruning can hide equally good alternative moves, so do not use it when all optimal moves are needed.
- Branching factor 1 and strictly "bad-first" trees: nothing is pruned (2/2 and 6/6 leaves).
- 2000 random trees (depth 3-4, branching 2-4): 0 value mismatches, alpha-beta never used more leaves, 36.0% fewer overall.
- Limits: the tree is small and assumed; leaf counts ignore the cost of sorting moves; real games need a good move-ordering
  heuristic, which can cost more than it saves, and the tree is fixed (no transposition tables or depth limits).

## 5. Learning outcome and reflection
Alpha-beta is an exact optimisation of Minimax: same answer, fewer evaluations when branch ordering is good.
Writing the leaf counter and checking `assert minimax == alphabeta` made that concrete. The trace showed that pruning
decisions depend on the order of discovery, not just the tree values.

## 6. Responsible practice
The tree is disclosed as assumed. Code is original standard-library Python; ideas follow Russell & Norvig, AIMA (adversarial
search chapter) and the standard Knuth-Moore analysis of alpha-beta. No private data or credentials included. In
real decision systems, "optimal against a perfect opponent" can be wrong if the opponent model or evaluation function is
poor, so outputs should be validated rather than trusted blindly.
